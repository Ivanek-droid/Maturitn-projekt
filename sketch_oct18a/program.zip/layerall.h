#ifndef __layerall_H__
#define __layerall_H__
#include "variables.h"


void layerall(){

for(int i = 0;i <=7;i++){




}

}

#endif